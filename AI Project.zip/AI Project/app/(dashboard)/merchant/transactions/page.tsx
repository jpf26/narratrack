import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { TransactionForm } from '@/components/transactions/TransactionForm'

export default async function TransactionsPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const [branches, campaigns] = await Promise.all([
    prisma.branch.findMany({
      where: { merchantId: merchant.id, isActive: true },
      orderBy: { name: 'asc' },
    }),
    prisma.campaign.findMany({
      where: {
        merchantId: merchant.id,
        isActive: true,
        startDate: { lte: new Date() },
        endDate: { gte: new Date() },
      },
      include: {
        branchCampaigns: {
          where: { isActive: true },
        },
      },
      orderBy: { name: 'asc' },
    }),
  ])

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Record Transaction</h1>
        <p className="text-muted-foreground">
          Scan customer QR code and record their transaction
        </p>
      </div>

      <TransactionForm
        branches={branches}
        campaigns={campaigns}
        merchantId={merchant.id}
      />
    </div>
  )
}
