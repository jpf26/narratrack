import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default async function MerchantLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link href="/dashboard/merchant" className="text-xl font-bold">
            Merchant Dashboard
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/dashboard/merchant">
              <Button variant="ghost" size="sm">Dashboard</Button>
            </Link>
            <Link href="/dashboard/merchant/transactions">
              <Button variant="ghost" size="sm">Transactions</Button>
            </Link>
            <Link href="/dashboard/merchant/campaigns">
              <Button variant="ghost" size="sm">Campaigns</Button>
            </Link>
            <Link href="/dashboard/merchant/branches">
              <Button variant="ghost" size="sm">Branches</Button>
            </Link>
            <Link href="/dashboard/merchant/customers">
              <Button variant="ghost" size="sm">Customers</Button>
            </Link>
            <Link href="/dashboard/merchant/email-campaigns">
              <Button variant="ghost" size="sm">Email Campaigns</Button>
            </Link>
            <span className="text-sm text-muted-foreground">
              {session.user.name}
            </span>
            <form action="/api/auth/signout" method="POST">
              <Button type="submit" variant="outline" size="sm">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </nav>
      <main className="container mx-auto px-4 py-8">{children}</main>
    </div>
  )
}
