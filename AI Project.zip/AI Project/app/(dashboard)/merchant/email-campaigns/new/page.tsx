import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { EmailCampaignForm } from '@/components/email/EmailCampaignForm'

export default async function NewEmailCampaignPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const campaigns = await prisma.campaign.findMany({
    where: { merchantId: merchant.id },
    select: { id: true, name: true },
  })

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Create Email Campaign</h1>
        <p className="text-muted-foreground">
          Send targeted emails to your customers
        </p>
      </div>

      <EmailCampaignForm merchantId={merchant.id} campaigns={campaigns} />
    </div>
  )
}
