import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default async function EmailCampaignsPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const emailCampaigns = await prisma.emailCampaign.findMany({
    where: { merchantId: merchant.id },
    include: {
      recipients: true,
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Email Campaigns</h1>
          <p className="text-muted-foreground">
            Create and manage email marketing campaigns
          </p>
        </div>
        <Link href="/dashboard/merchant/email-campaigns/new">
          <Button>Create Campaign</Button>
        </Link>
      </div>

      {emailCampaigns.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No email campaigns yet</p>
            <Link href="/dashboard/merchant/email-campaigns/new">
              <Button>Create Your First Campaign</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {emailCampaigns.map((campaign) => {
            const sentCount = campaign.recipients.filter(
              (r) => r.status === 'SENT'
            ).length
            const totalCount = campaign.recipients.length

            return (
              <Card key={campaign.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{campaign.name}</CardTitle>
                      <CardDescription>{campaign.subject}</CardDescription>
                    </div>
                    <span
                      className={`rounded-full px-2 py-1 text-xs ${
                        campaign.status === 'SENT'
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                          : campaign.status === 'SCHEDULED'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                          : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                      }`}
                    >
                      {campaign.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-sm">
                    <div>
                      <span className="text-muted-foreground">Recipients: </span>
                      {sentCount} / {totalCount} sent
                    </div>
                    {campaign.sentAt && (
                      <div>
                        <span className="text-muted-foreground">Sent: </span>
                        {new Date(campaign.sentAt).toLocaleString()}
                      </div>
                    )}
                    {campaign.scheduledAt && (
                      <div>
                        <span className="text-muted-foreground">Scheduled: </span>
                        {new Date(campaign.scheduledAt).toLocaleString()}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
