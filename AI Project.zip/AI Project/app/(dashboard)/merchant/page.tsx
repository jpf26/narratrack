import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default async function MerchantDashboard() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const [branches, campaigns, totalCustomers, recentTransactions] = await Promise.all([
    prisma.branch.count({ where: { merchantId: merchant.id } }),
    prisma.campaign.count({ where: { merchantId: merchant.id } }),
    prisma.customerCampaignProgress.findMany({
      where: {
        branch: { merchantId: merchant.id },
      },
      select: { customerId: true },
      distinct: ['customerId'],
    }),
    prisma.transaction.findMany({
      where: {
        branch: { merchantId: merchant.id },
      },
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        customer: {
          include: { user: true },
        },
        branch: true,
        campaign: true,
      },
    }),
  ])

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back, {merchant.businessName}
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Branches</CardTitle>
            <CardDescription>Total branches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{branches}</div>
            <Link href="/dashboard/merchant/branches">
              <Button variant="link" className="p-0 mt-2">
                Manage branches →
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Campaigns</CardTitle>
            <CardDescription>Active campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{campaigns}</div>
            <Link href="/dashboard/merchant/campaigns">
              <Button variant="link" className="p-0 mt-2">
                Manage campaigns →
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customers</CardTitle>
            <CardDescription>Total customers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalCustomers.length}</div>
            <Link href="/dashboard/merchant/customers">
              <Button variant="link" className="p-0 mt-2">
                View customers →
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Latest transaction activity</CardDescription>
        </CardHeader>
        <CardContent>
          {recentTransactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No transactions yet
            </div>
          ) : (
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                >
                  <div>
                    <div className="font-medium">
                      {transaction.customer.user.name}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {transaction.branch.name} •{' '}
                      {new Date(transaction.createdAt).toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">
                      ${transaction.spend.toNumber().toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      +{transaction.pointsEarned.toNumber().toFixed(0)} pts
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
