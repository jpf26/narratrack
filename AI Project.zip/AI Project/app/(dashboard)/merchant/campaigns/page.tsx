import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default async function CampaignsPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const campaigns = await prisma.campaign.findMany({
    where: { merchantId: merchant.id },
    include: {
      promos: true,
      milestones: {
        orderBy: { order: 'asc' },
      },
      branchCampaigns: {
        include: {
          branch: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Campaigns</h1>
          <p className="text-muted-foreground">
            Manage your loyalty campaigns
          </p>
        </div>
        <Link href="/dashboard/merchant/campaigns/new">
          <Button>Create Campaign</Button>
        </Link>
      </div>

      {campaigns.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No campaigns yet</p>
            <Link href="/dashboard/merchant/campaigns/new">
              <Button>Create Your First Campaign</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {campaigns.map((campaign) => {
            const now = new Date()
            const isActive = campaign.isActive &&
              campaign.startDate <= now &&
              campaign.endDate >= now

            return (
              <Card key={campaign.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{campaign.name}</CardTitle>
                      <CardDescription>{campaign.description}</CardDescription>
                    </div>
                    <span
                      className={`rounded-full px-2 py-1 text-xs ${
                        isActive
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                          : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                      }`}
                    >
                      {isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-sm">
                    <div>
                      <span className="text-muted-foreground">Period: </span>
                      {new Date(campaign.startDate).toLocaleDateString()} -{' '}
                      {new Date(campaign.endDate).toLocaleDateString()}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Promos: </span>
                      {campaign.promos.length}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Milestones: </span>
                      {campaign.milestones.length}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Branches: </span>
                      {campaign.branchCampaigns.length}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/dashboard/merchant/campaigns/${campaign.id}`}>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </Link>
                    <Link href={`/dashboard/merchant/campaigns/${campaign.id}/clone`}>
                      <Button variant="outline" size="sm">
                        Clone to Branches
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
