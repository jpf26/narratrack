import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { CampaignForm } from '@/components/campaigns/CampaignForm'
import { prisma } from '@/lib/db'

export default async function NewCampaignPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Create Campaign</h1>
        <p className="text-muted-foreground">
          Create a new loyalty campaign with promos and milestones
        </p>
      </div>

      <CampaignForm merchantId={merchant.id} />
    </div>
  )
}
