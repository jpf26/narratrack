import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { BranchCloner } from '@/components/campaigns/BranchCloner'

export default async function CloneCampaignPage({
  params,
}: {
  params: { id: string }
}) {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const [campaign, branches] = await Promise.all([
    prisma.campaign.findUnique({
      where: { id: params.id },
      include: { merchant: true },
    }),
    prisma.branch.findMany({
      where: { merchantId: merchant.id, isActive: true },
      orderBy: { name: 'asc' },
    }),
  ])

  if (!campaign || campaign.merchant.userId !== session.user.id) {
    redirect('/dashboard/merchant/campaigns')
  }

  const existingBranchCampaigns = await prisma.branchCampaign.findMany({
    where: { campaignId: params.id },
    select: { branchId: true },
  })

  const existingBranchIds = existingBranchCampaigns.map((bc) => bc.branchId)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Clone Campaign to Branches</h1>
        <p className="text-muted-foreground">
          Select branches to activate this campaign
        </p>
      </div>

      <BranchCloner
        campaignId={params.id}
        branches={branches}
        existingBranchIds={existingBranchIds}
      />
    </div>
  )
}
