import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { CampaignForm } from '@/components/campaigns/CampaignForm'

export default async function EditCampaignPage({
  params,
}: {
  params: { id: string }
}) {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const campaign = await prisma.campaign.findUnique({
    where: { id: params.id },
    include: {
      promos: true,
      milestones: {
        orderBy: { order: 'asc' },
      },
      merchant: true,
    },
  })

  if (!campaign || campaign.merchant.userId !== session.user.id) {
    redirect('/dashboard/merchant/campaigns')
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Edit Campaign</h1>
        <p className="text-muted-foreground">
          Update campaign details, promos, and milestones
        </p>
      </div>

      <CampaignForm
        merchantId={merchant.id}
        campaign={{
          id: campaign.id,
          name: campaign.name,
          description: campaign.description || undefined,
          startDate: campaign.startDate.toISOString(),
          endDate: campaign.endDate.toISOString(),
          isActive: campaign.isActive,
          promos: campaign.promos.map((p) => ({
            promoType: p.promoType,
            multiplier: p.multiplier.toNumber(),
            minSpend: p.minSpend?.toNumber(),
          })),
          milestones: campaign.milestones.map((m) => ({
            rewardName: m.rewardName,
            pointsNeeded: m.pointsNeeded,
            rewardDescription: m.rewardDescription || undefined,
            order: m.order,
          })),
        }}
      />
    </div>
  )
}
