import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CustomerTable } from '@/components/customers/CustomerTable'

export default async function CustomersPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const [customers, campaigns] = await Promise.all([
    prisma.customerCampaignProgress.findMany({
      where: {
        branch: { merchantId: merchant.id },
      },
      include: {
        customer: {
          include: {
            user: true,
          },
        },
        branch: true,
        campaign: true,
      },
      distinct: ['customerId'],
    }),
    prisma.campaign.findMany({
      where: { merchantId: merchant.id },
      select: { id: true, name: true },
    }),
  ])

  // Aggregate customer data
  const customerMap = new Map()
  for (const progress of customers) {
    const customerId = progress.customerId
    if (!customerMap.has(customerId)) {
      customerMap.set(customerId, {
        customer: progress.customer,
        totalPoints: 0,
        lastVisit: null,
        campaigns: [],
        eligibleRewards: 0,
        redeemedRewards: 0,
      })
    }
    const data = customerMap.get(customerId)
    data.totalPoints += progress.pointsAccumulated.toNumber()
    if (progress.lastTransactionAt) {
      if (!data.lastVisit || progress.lastTransactionAt > data.lastVisit) {
        data.lastVisit = progress.lastTransactionAt
      }
    }
    const eligible = Array.isArray(progress.rewardsEligible)
      ? progress.rewardsEligible.length
      : 0
    const redeemed = Array.isArray(progress.rewardsRedeemed)
      ? progress.rewardsRedeemed.length
      : 0
    data.eligibleRewards += eligible
    data.redeemedRewards += redeemed
    data.campaigns.push({
      campaignId: progress.campaignId,
      campaignName: progress.campaign.name,
      points: progress.pointsAccumulated.toNumber(),
    })
  }

  const customerList = Array.from(customerMap.values())

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Customers</h1>
          <p className="text-muted-foreground">
            View and manage your customer base
          </p>
        </div>
        <Link href="/dashboard/merchant/email-campaigns/new">
          <Button>Create Email Campaign</Button>
        </Link>
      </div>

      <CustomerTable customers={customerList} campaigns={campaigns} />
    </div>
  )
}
