import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default async function BranchesPage() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const merchant = await prisma.merchant.findUnique({
    where: { userId: session.user.id },
  })

  if (!merchant) {
    redirect('/login')
  }

  const branches = await prisma.branch.findMany({
    where: { merchantId: merchant.id },
    orderBy: { name: 'asc' },
  })

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Branches</h1>
          <p className="text-muted-foreground">
            Manage your business branches
          </p>
        </div>
        <Link href="/dashboard/merchant/branches/new">
          <Button>Add Branch</Button>
        </Link>
      </div>

      {branches.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No branches yet</p>
            <Link href="/dashboard/merchant/branches/new">
              <Button>Add Your First Branch</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {branches.map((branch) => (
            <Card key={branch.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{branch.name}</CardTitle>
                    <CardDescription>{branch.address}</CardDescription>
                  </div>
                  <span
                    className={`rounded-full px-2 py-1 text-xs ${
                      branch.isActive
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                    }`}
                  >
                    {branch.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-1">
                  {branch.phone && (
                    <div>
                      <span className="text-muted-foreground">Phone: </span>
                      {branch.phone}
                    </div>
                  )}
                  <div>
                    <span className="text-muted-foreground">Created: </span>
                    {new Date(branch.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
