import { redirect } from 'next/navigation'
import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export default async function CustomerDashboard() {
  const session = await getServerSession(authOptions)

  if (!session || (session.user.role !== 'customer' && session.user.role !== 'both')) {
    redirect('/login')
  }

  const customer = await prisma.customer.findUnique({
    where: { userId: session.user.id },
    include: {
      user: true,
    },
  })

  if (!customer) {
    redirect('/login')
  }

  const progress = await prisma.customerCampaignProgress.findMany({
    where: { customerId: customer.id },
    include: {
      campaign: {
        include: {
          merchant: true,
          milestones: {
            orderBy: { order: 'asc' },
          },
        },
      },
      branch: true,
    },
    orderBy: { updatedAt: 'desc' },
  })

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My Progress</h1>
        <p className="text-muted-foreground">
          Track your loyalty points and rewards
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>My QR Code</CardTitle>
            <CardDescription>
              Show this QR code to staff to earn points
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/dashboard/customer/qr">
              <Button className="w-full">View QR Code</Button>
            </Link>
          </CardContent>
        </Card>

        {progress.length === 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>No Progress Yet</CardTitle>
              <CardDescription>
                Start earning points by visiting merchants and showing your QR code
              </CardDescription>
            </CardHeader>
          </Card>
        ) : (
          progress.map((p) => (
            <Card key={p.id}>
              <CardHeader>
                <CardTitle>{p.campaign.name}</CardTitle>
                <CardDescription>
                  {p.branch.name} • {p.campaign.merchant.businessName}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-2xl font-bold">
                    {p.pointsAccumulated.toNumber().toFixed(0)} points
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Last updated:{' '}
                    {p.lastTransactionAt
                      ? new Date(p.lastTransactionAt).toLocaleDateString()
                      : 'Never'}
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Eligible Rewards</div>
                  {p.rewardsEligible && Array.isArray(p.rewardsEligible) && p.rewardsEligible.length > 0 ? (
                    <div className="space-y-1">
                      {p.rewardsEligible.map((milestoneId: string) => {
                        const milestone = p.campaign.milestones.find(
                          (m) => m.id === milestoneId
                        )
                        return milestone ? (
                          <div
                            key={milestoneId}
                            className="rounded-md bg-primary/10 p-2 text-sm"
                          >
                            {milestone.rewardName}
                            {milestone.rewardDescription && (
                              <div className="text-xs text-muted-foreground mt-1">
                                {milestone.rewardDescription}
                              </div>
                            )}
                          </div>
                        ) : null
                      })}
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">
                      No rewards eligible yet
                    </div>
                  )}
                </div>
                {p.campaign.milestones.length > 0 && (
                  <div className="space-y-2">
                    <div className="text-sm font-medium">All Milestones</div>
                    <div className="space-y-1">
                      {p.campaign.milestones.map((milestone) => {
                        const isEligible = Array.isArray(p.rewardsEligible) && p.rewardsEligible.includes(milestone.id)
                        const isRedeemed = Array.isArray(p.rewardsRedeemed) && p.rewardsRedeemed.includes(milestone.id)
                        return (
                          <div
                            key={milestone.id}
                            className={`rounded-md p-2 text-sm ${
                              isRedeemed
                                ? 'bg-muted opacity-50'
                                : isEligible
                                ? 'bg-primary/10'
                                : 'bg-muted/50'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span>{milestone.rewardName}</span>
                              <span className="text-xs text-muted-foreground">
                                {milestone.pointsNeeded} pts
                              </span>
                            </div>
                            {isRedeemed && (
                              <div className="text-xs text-muted-foreground mt-1">
                                Redeemed
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
                </div>
              </CardContent>
            </Card>
          ))
        ))}
      </div>
    </div>
  )
}
