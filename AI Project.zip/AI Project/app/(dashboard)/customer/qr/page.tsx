'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { QRCodeSVG } from 'qrcode.react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default function QRCodePage() {
  const { data: session } = useSession()
  const [qrValue, setQrValue] = useState('')

  useEffect(() => {
    if (session?.user?.id) {
      // Encode customer ID in QR code
      // In production, you might want to use a signed JWT token instead
      setQrValue(session.user.id)
    }
  }, [session])

  if (!qrValue) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My QR Code</h1>
        <p className="text-muted-foreground">
          Show this QR code to staff to record transactions and earn points
        </p>
      </div>

      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Scan to Earn Points</CardTitle>
          <CardDescription>
            Present this QR code at any participating merchant location
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-6">
          <div className="p-4 bg-white rounded-lg">
            <QRCodeSVG value={qrValue} size={256} level="H" />
          </div>
          <div className="text-center space-y-2">
            <p className="text-sm font-medium">{session?.user?.name}</p>
            <p className="text-xs text-muted-foreground">{session?.user?.email}</p>
          </div>
          <Link href="/dashboard/customer">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
