import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Decimal } from '@prisma/client/runtime/library'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { merchantId, name, description, startDate, endDate, promos, milestones } = body

    // Verify merchant
    const merchant = await prisma.merchant.findUnique({
      where: { id: merchantId },
    })

    if (!merchant || merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Create campaign with promos and milestones
    const campaign = await prisma.campaign.create({
      data: {
        merchantId,
        name,
        description: description || null,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        promos: {
          create: promos.map((p: any) => ({
            promoType: p.promoType,
            multiplier: new Decimal(p.multiplier),
            minSpend: p.minSpend ? new Decimal(p.minSpend) : null,
          })),
        },
        milestones: {
          create: milestones.map((m: any, index: number) => ({
            rewardName: m.rewardName,
            pointsNeeded: m.pointsNeeded,
            rewardDescription: m.rewardDescription || null,
            order: m.order || index + 1,
          })),
        },
      },
    })

    return NextResponse.json({ success: true, campaign })
  } catch (error) {
    console.error('Campaign creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
