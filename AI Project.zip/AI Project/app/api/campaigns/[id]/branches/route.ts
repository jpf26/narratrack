import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { branchIds } = body

    // Verify campaign exists and belongs to merchant
    const campaign = await prisma.campaign.findUnique({
      where: { id: params.id },
      include: { merchant: true },
    })

    if (!campaign) {
      return NextResponse.json(
        { error: 'Campaign not found' },
        { status: 404 }
      )
    }

    if (campaign.merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Verify all branches belong to merchant
    const branches = await prisma.branch.findMany({
      where: {
        id: { in: branchIds },
        merchantId: campaign.merchantId,
      },
    })

    if (branches.length !== branchIds.length) {
      return NextResponse.json(
        { error: 'Some branches not found or unauthorized' },
        { status: 400 }
      )
    }

    // Delete existing branch-campaign links
    await prisma.branchCampaign.deleteMany({
      where: { campaignId: params.id },
    })

    // Create new branch-campaign links
    await prisma.branchCampaign.createMany({
      data: branchIds.map((branchId: string) => ({
        branchId,
        campaignId: params.id,
        isActive: true,
      })),
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Branch cloning error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
