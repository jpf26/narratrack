import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Decimal } from '@prisma/client/runtime/library'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const campaign = await prisma.campaign.findUnique({
      where: { id: params.id },
      include: {
        promos: true,
        milestones: {
          orderBy: { order: 'asc' },
        },
        merchant: true,
      },
    })

    if (!campaign) {
      return NextResponse.json(
        { error: 'Campaign not found' },
        { status: 404 }
      )
    }

    if (campaign.merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    return NextResponse.json({ campaign })
  } catch (error) {
    console.error('Campaign fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { name, description, startDate, endDate, promos, milestones } = body

    // Verify campaign exists and belongs to merchant
    const existingCampaign = await prisma.campaign.findUnique({
      where: { id: params.id },
      include: { merchant: true },
    })

    if (!existingCampaign) {
      return NextResponse.json(
        { error: 'Campaign not found' },
        { status: 404 }
      )
    }

    if (existingCampaign.merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Update campaign
    const campaign = await prisma.campaign.update({
      where: { id: params.id },
      data: {
        name,
        description: description || null,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
      },
    })

    // Delete existing promos and milestones
    await Promise.all([
      prisma.campaignPromo.deleteMany({
        where: { campaignId: params.id },
      }),
      prisma.campaignMilestone.deleteMany({
        where: { campaignId: params.id },
      }),
    ])

    // Create new promos and milestones
    await Promise.all([
      prisma.campaignPromo.createMany({
        data: promos.map((p: any) => ({
          campaignId: params.id,
          promoType: p.promoType,
          multiplier: new Decimal(p.multiplier),
          minSpend: p.minSpend ? new Decimal(p.minSpend) : null,
        })),
      }),
      prisma.campaignMilestone.createMany({
        data: milestones.map((m: any, index: number) => ({
          campaignId: params.id,
          rewardName: m.rewardName,
          pointsNeeded: m.pointsNeeded,
          rewardDescription: m.rewardDescription || null,
          order: m.order || index + 1,
        })),
      }),
    ])

    return NextResponse.json({ success: true, campaign })
  } catch (error) {
    console.error('Campaign update error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
