import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { resolveRecipients } from '@/lib/segments'
import { sendEmail } from '@/lib/email'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { merchantId, name, subject, body: emailBody, segment } = body

    // Verify merchant
    const merchant = await prisma.merchant.findUnique({
      where: { id: merchantId },
    })

    if (!merchant || merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Resolve recipients
    const recipients = await resolveRecipients(segment, merchantId)

    // Create email campaign
    const emailCampaign = await prisma.emailCampaign.create({
      data: {
        merchantId,
        name,
        subject,
        body: emailBody,
        segment: segment || {},
        status: 'DRAFT',
      },
    })

    // Create recipient records
    await prisma.emailCampaignRecipient.createMany({
      data: recipients.map((r) => ({
        emailCampaignId: emailCampaign.id,
        customerId: r.customerId,
        status: 'PENDING',
      })),
    })

    // Send emails (in production, you might want to do this in a background job)
    const recipientRecords = await prisma.emailCampaignRecipient.findMany({
      where: { emailCampaignId: emailCampaign.id },
      include: {
        customer: {
          include: { user: true },
        },
      },
    })

    let sentCount = 0
    let failedCount = 0

    for (const recipient of recipientRecords) {
      try {
        await sendEmail({
          to: recipient.customer.user.email,
          subject,
          html: emailBody.replace(/\n/g, '<br>'),
        })

        await prisma.emailCampaignRecipient.update({
          where: { id: recipient.id },
          data: {
            status: 'SENT',
            sentAt: new Date(),
          },
        })

        sentCount++
      } catch (error) {
        await prisma.emailCampaignRecipient.update({
          where: { id: recipient.id },
          data: {
            status: 'FAILED',
            errorMessage: error instanceof Error ? error.message : 'Unknown error',
          },
        })

        failedCount++
      }
    }

    // Update campaign status
    await prisma.emailCampaign.update({
      where: { id: emailCampaign.id },
      data: {
        status: 'SENT',
        sentAt: new Date(),
      },
    })

    return NextResponse.json({
      success: true,
      emailCampaign,
      stats: {
        total: recipients.length,
        sent: sentCount,
        failed: failedCount,
      },
    })
  } catch (error) {
    console.error('Email campaign error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
