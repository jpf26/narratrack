import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { calculatePoints } from '@/lib/points'
import { updateRewardsEligible } from '@/lib/milestones'
import { Decimal } from '@prisma/client/runtime/library'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || (session.user.role !== 'merchant' && session.user.role !== 'both')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { customerId, branchId, campaignId, spend, quantity, visit, notes } = body

    // Validate required fields
    if (!customerId || !branchId || spend === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Verify customer exists
    const customer = await prisma.customer.findUnique({
      where: { id: customerId },
    })

    if (!customer) {
      return NextResponse.json(
        { error: 'Customer not found' },
        { status: 404 }
      )
    }

    // Verify branch exists and belongs to merchant
    const branch = await prisma.branch.findUnique({
      where: { id: branchId },
      include: { merchant: true },
    })

    if (!branch) {
      return NextResponse.json(
        { error: 'Branch not found' },
        { status: 404 }
      )
    }

    if (session.user.role !== 'both' && branch.merchant.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    let campaign = null
    let pointsEarned = new Decimal(0)

    // If campaign is specified, validate and calculate points
    if (campaignId) {
      campaign = await prisma.campaign.findUnique({
        where: { id: campaignId },
        include: {
          promos: true,
          milestones: {
            orderBy: { order: 'asc' },
          },
          branchCampaigns: {
            where: {
              branchId,
              isActive: true,
            },
          },
        },
      })

      if (!campaign) {
        return NextResponse.json(
          { error: 'Campaign not found' },
          { status: 404 }
        )
      }

      // Check if campaign is active and linked to branch
      const branchCampaign = campaign.branchCampaigns[0]
      if (!branchCampaign || !branchCampaign.isActive) {
        return NextResponse.json(
          { error: 'Campaign is not active for this branch' },
          { status: 400 }
        )
      }

      // Check if campaign is within date range
      const now = new Date()
      if (campaign.startDate > now || campaign.endDate < now) {
        return NextResponse.json(
          { error: 'Campaign is not currently active' },
          { status: 400 }
        )
      }

      // Calculate points
      pointsEarned = new Decimal(
        calculatePoints(
          { spend, quantity: quantity || 1, visit: visit !== false },
          campaign.promos.map((p) => ({
            promoType: p.promoType,
            multiplier: p.multiplier,
            minSpend: p.minSpend,
          }))
        )
      )
    } else {
      // No campaign - just use spend as base points
      pointsEarned = new Decimal(spend)
    }

    // Use transaction to ensure atomicity
    const result = await prisma.$transaction(async (tx) => {
      // Create transaction record
      const transaction = await tx.transaction.create({
        data: {
          customerId,
          branchId,
          campaignId: campaignId || null,
          staffUserId: session.user.id,
          spend: new Decimal(spend),
          quantity: quantity || 1,
          visit: visit !== false,
          pointsEarned,
          notes: notes || null,
        },
      })

      // Update or create progress if campaign exists
      if (campaign) {
        const existingProgress = await tx.customerCampaignProgress.findUnique({
          where: {
            customerId_branchId_campaignId: {
              customerId,
              branchId,
              campaignId,
            },
          },
        })

        const newPointsAccumulated = existingProgress
          ? existingProgress.pointsAccumulated.plus(pointsEarned)
          : pointsEarned

        const currentRewardsEligible = existingProgress
          ? (existingProgress.rewardsEligible as string[]) || []
          : []
        const currentRewardsRedeemed = existingProgress
          ? (existingProgress.rewardsRedeemed as string[]) || []
          : []

        // Update eligible rewards
        const updatedRewardsEligible = updateRewardsEligible(
          {
            pointsAccumulated: newPointsAccumulated,
            rewardsEligible: currentRewardsEligible,
            rewardsRedeemed: currentRewardsRedeemed,
          },
          campaign.milestones.map((m) => ({
            id: m.id,
            pointsNeeded: m.pointsNeeded,
          }))
        )

        const progress = await tx.customerCampaignProgress.upsert({
          where: {
            customerId_branchId_campaignId: {
              customerId,
              branchId,
              campaignId,
            },
          },
          create: {
            customerId,
            branchId,
            campaignId,
            pointsAccumulated: newPointsAccumulated,
            rewardsEligible: updatedRewardsEligible,
            rewardsRedeemed: [],
            lastTransactionAt: new Date(),
          },
          update: {
            pointsAccumulated: newPointsAccumulated,
            rewardsEligible: updatedRewardsEligible,
            lastTransactionAt: new Date(),
          },
        })

        // Create history entry
        await tx.customerCampaignProgressHistory.create({
          data: {
            customerCampaignProgressId: progress.id,
            customerId,
            branchId,
            campaignId,
            pointsAccumulated: newPointsAccumulated,
            rewardsEligible: updatedRewardsEligible,
            rewardsRedeemed: currentRewardsRedeemed,
            changeType: 'TRANSACTION',
            transactionId: transaction.id,
            changedBy: session.user.id,
          },
        })

        return { transaction, progress, pointsEarned: newPointsAccumulated }
      }

      return { transaction, progress: null, pointsEarned }
    })

    return NextResponse.json({
      success: true,
      transaction: {
        id: result.transaction.id,
        pointsEarned: result.pointsEarned.toNumber(),
      },
      progress: result.progress
        ? {
            pointsAccumulated: result.progress.pointsAccumulated.toNumber(),
            rewardsEligible: result.progress.rewardsEligible,
          }
        : null,
    })
  } catch (error) {
    console.error('Transaction error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
