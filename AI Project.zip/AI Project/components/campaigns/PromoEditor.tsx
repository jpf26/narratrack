'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export interface Promo {
  promoType: 'SPEND_MULTIPLIER' | 'QUANTITY_MULTIPLIER' | 'VISIT_MULTIPLIER' | 'FLAT_BONUS'
  multiplier: number
  minSpend?: number
}

interface PromoEditorProps {
  promos: Promo[]
  onChange: (promos: Promo[]) => void
}

export function PromoEditor({ promos, onChange }: PromoEditorProps) {
  const addPromo = () => {
    onChange([
      ...promos,
      {
        promoType: 'SPEND_MULTIPLIER',
        multiplier: 1.5,
      },
    ])
  }

  const updatePromo = (index: number, updates: Partial<Promo>) => {
    const updated = [...promos]
    updated[index] = { ...updated[index], ...updates }
    onChange(updated)
  }

  const removePromo = (index: number) => {
    onChange(promos.filter((_, i) => i !== index))
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Promos</CardTitle>
            <CardDescription>
              Define point multipliers and bonuses
            </CardDescription>
          </div>
          <Button type="button" onClick={addPromo} size="sm">
            Add Promo
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {promos.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No promos added yet
          </div>
        ) : (
          promos.map((promo, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Promo {index + 1}</h4>
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  onClick={() => removePromo(index)}
                >
                  Remove
                </Button>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Promo Type</Label>
                  <select
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    value={promo.promoType}
                    onChange={(e) =>
                      updatePromo(index, {
                        promoType: e.target.value as Promo['promoType'],
                      })
                    }
                  >
                    <option value="SPEND_MULTIPLIER">Spend Multiplier</option>
                    <option value="QUANTITY_MULTIPLIER">Quantity Multiplier</option>
                    <option value="VISIT_MULTIPLIER">Visit Multiplier</option>
                    <option value="FLAT_BONUS">Flat Bonus</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Multiplier / Bonus Amount</Label>
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    value={promo.multiplier}
                    onChange={(e) =>
                      updatePromo(index, {
                        multiplier: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    {promo.promoType === 'FLAT_BONUS'
                      ? 'Flat bonus points added'
                      : 'Multiplier (e.g., 1.5 = 1.5x points)'}
                  </p>
                </div>
                {(promo.promoType === 'SPEND_MULTIPLIER' ||
                  promo.promoType === 'QUANTITY_MULTIPLIER') && (
                  <div className="space-y-2">
                    <Label>Minimum Spend (Optional)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={promo.minSpend || ''}
                      onChange={(e) =>
                        updatePromo(index, {
                          minSpend: e.target.value
                            ? parseFloat(e.target.value)
                            : undefined,
                        })
                      }
                      placeholder="No minimum"
                    />
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
