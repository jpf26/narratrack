'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface Branch {
  id: string
  name: string
}

interface BranchClonerProps {
  campaignId: string
  branches: Branch[]
  existingBranchIds: string[]
}

export function BranchCloner({
  campaignId,
  branches,
  existingBranchIds,
}: BranchClonerProps) {
  const router = useRouter()
  const [selectedBranchIds, setSelectedBranchIds] = useState<string[]>(
    existingBranchIds
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const toggleBranch = (branchId: string) => {
    setSelectedBranchIds((prev) =>
      prev.includes(branchId)
        ? prev.filter((id) => id !== branchId)
        : [...prev, branchId]
    )
  }

  const handleSubmit = async () => {
    setError('')
    setLoading(true)

    try {
      const response = await fetch(`/api/campaigns/${campaignId}/branches`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ branchIds: selectedBranchIds }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to update branches')
        setLoading(false)
        return
      }

      router.push('/dashboard/merchant/campaigns')
      router.refresh()
    } catch (err) {
      setError('An error occurred. Please try again.')
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Branches</CardTitle>
        <CardDescription>
          Choose which branches should have this campaign active
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <div className="rounded-md bg-destructive/15 p-3 text-sm text-destructive">
            {error}
          </div>
        )}

        {branches.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No branches available. Create branches first.
          </div>
        ) : (
          <>
            <div className="space-y-2">
              {branches.map((branch) => (
                <div
                  key={branch.id}
                  className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer hover:bg-accent"
                  onClick={() => toggleBranch(branch.id)}
                >
                  <input
                    type="checkbox"
                    checked={selectedBranchIds.includes(branch.id)}
                    onChange={() => toggleBranch(branch.id)}
                    className="h-4 w-4"
                  />
                  <label className="flex-1 cursor-pointer">
                    {branch.name}
                    {existingBranchIds.includes(branch.id) && (
                      <span className="ml-2 text-xs text-muted-foreground">
                        (already active)
                      </span>
                    )}
                  </label>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <Button onClick={handleSubmit} disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </Button>
              <Button variant="outline" onClick={() => router.back()}>
                Cancel
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
