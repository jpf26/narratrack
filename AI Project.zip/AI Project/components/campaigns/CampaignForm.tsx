'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { PromoEditor } from './PromoEditor'
import { MilestoneEditor } from './MilestoneEditor'

interface Promo {
  promoType: 'SPEND_MULTIPLIER' | 'QUANTITY_MULTIPLIER' | 'VISIT_MULTIPLIER' | 'FLAT_BONUS'
  multiplier: number
  minSpend?: number
}

interface Milestone {
  rewardName: string
  pointsNeeded: number
  rewardDescription?: string
  order: number
}

interface CampaignFormProps {
  merchantId: string
  campaign?: {
    id: string
    name: string
    description?: string
    startDate: string
    endDate: string
    isActive: boolean
    promos: Promo[]
    milestones: Milestone[]
  }
}

export function CampaignForm({ merchantId, campaign }: CampaignFormProps) {
  const router = useRouter()
  const [name, setName] = useState(campaign?.name || '')
  const [description, setDescription] = useState(campaign?.description || '')
  const [startDate, setStartDate] = useState(
    campaign?.startDate ? new Date(campaign.startDate).toISOString().split('T')[0] : ''
  )
  const [endDate, setEndDate] = useState(
    campaign?.endDate ? new Date(campaign.endDate).toISOString().split('T')[0] : ''
  )
  const [promos, setPromos] = useState<Promo[]>(campaign?.promos || [])
  const [milestones, setMilestones] = useState<Milestone[]>(campaign?.milestones || [])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!name || !startDate || !endDate) {
      setError('Please fill in all required fields')
      return
    }

    if (new Date(startDate) >= new Date(endDate)) {
      setError('End date must be after start date')
      return
    }

    setLoading(true)

    try {
      const url = campaign
        ? `/api/campaigns/${campaign.id}`
        : '/api/campaigns'
      const method = campaign ? 'PUT' : 'POST'

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchantId,
          name,
          description: description || null,
          startDate,
          endDate,
          promos,
          milestones,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to save campaign')
        setLoading(false)
        return
      }

      router.push('/dashboard/merchant/campaigns')
      router.refresh()
    } catch (err) {
      setError('An error occurred. Please try again.')
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="rounded-md bg-destructive/15 p-3 text-sm text-destructive">
          {error}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
          <CardDescription>Campaign name and dates</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Campaign Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="startDate">Start Date *</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">End Date *</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                required
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <PromoEditor promos={promos} onChange={setPromos} />
      <MilestoneEditor milestones={milestones} onChange={setMilestones} />

      <div className="flex gap-4">
        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : campaign ? 'Update Campaign' : 'Create Campaign'}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
        >
          Cancel
        </Button>
      </div>
    </form>
  )
}
