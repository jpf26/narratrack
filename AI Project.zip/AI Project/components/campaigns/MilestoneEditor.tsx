'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export interface Milestone {
  rewardName: string
  pointsNeeded: number
  rewardDescription?: string
  order: number
}

interface MilestoneEditorProps {
  milestones: Milestone[]
  onChange: (milestones: Milestone[]) => void
}

export function MilestoneEditor({
  milestones,
  onChange,
}: MilestoneEditorProps) {
  const addMilestone = () => {
    onChange([
      ...milestones,
      {
        rewardName: '',
        pointsNeeded: 0,
        rewardDescription: '',
        order: milestones.length + 1,
      },
    ])
  }

  const updateMilestone = (index: number, updates: Partial<Milestone>) => {
    const updated = [...milestones]
    updated[index] = { ...updated[index], ...updates }
    onChange(updated)
  }

  const removeMilestone = (index: number) => {
    const updated = milestones
      .filter((_, i) => i !== index)
      .map((m, i) => ({ ...m, order: i + 1 }))
    onChange(updated)
  }

  const moveUp = (index: number) => {
    if (index === 0) return
    const updated = [...milestones]
    ;[updated[index - 1], updated[index]] = [updated[index], updated[index - 1]]
    updated[index - 1].order = index
    updated[index].order = index + 1
    onChange(updated)
  }

  const moveDown = (index: number) => {
    if (index === milestones.length - 1) return
    const updated = [...milestones]
    ;[updated[index], updated[index + 1]] = [updated[index + 1], updated[index]]
    updated[index].order = index + 1
    updated[index + 1].order = index + 2
    onChange(updated)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Milestones</CardTitle>
            <CardDescription>
              Define reward milestones based on points
            </CardDescription>
          </div>
          <Button type="button" onClick={addMilestone} size="sm">
            Add Milestone
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {milestones.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No milestones added yet
          </div>
        ) : (
          milestones.map((milestone, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Milestone {index + 1}</h4>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => moveUp(index)}
                    disabled={index === 0}
                  >
                    ↑
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => moveDown(index)}
                    disabled={index === milestones.length - 1}
                  >
                    ↓
                  </Button>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => removeMilestone(index)}
                  >
                    Remove
                  </Button>
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Reward Name *</Label>
                  <Input
                    value={milestone.rewardName}
                    onChange={(e) =>
                      updateMilestone(index, { rewardName: e.target.value })
                    }
                    placeholder="e.g., Free Coffee"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Points Needed *</Label>
                  <Input
                    type="number"
                    min="0"
                    value={milestone.pointsNeeded}
                    onChange={(e) =>
                      updateMilestone(index, {
                        pointsNeeded: parseInt(e.target.value) || 0,
                      })
                    }
                    required
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Reward Description</Label>
                  <Input
                    value={milestone.rewardDescription || ''}
                    onChange={(e) =>
                      updateMilestone(index, {
                        rewardDescription: e.target.value,
                      })
                    }
                    placeholder="Optional description"
                  />
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
