'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { QRScanner } from '@/components/qr/QRScanner'

interface Branch {
  id: string
  name: string
}

interface Campaign {
  id: string
  name: string
}

interface TransactionFormProps {
  branches: Branch[]
  campaigns: Campaign[]
  merchantId: string
}

export function TransactionForm({ branches, campaigns, merchantId }: TransactionFormProps) {
  const router = useRouter()
  const [selectedBranchId, setSelectedBranchId] = useState('')
  const [selectedCampaignId, setSelectedCampaignId] = useState('')
  const [customerId, setCustomerId] = useState('')
  const [spend, setSpend] = useState('')
  const [quantity, setQuantity] = useState('1')
  const [visit, setVisit] = useState(true)
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const availableCampaigns = campaigns.filter((campaign) => {
    // In a real implementation, filter by branch-campaign relationship
    return true
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess(false)

    if (!selectedBranchId || !customerId || !spend) {
      setError('Please fill in all required fields')
      return
    }

    setLoading(true)

    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId,
          branchId: selectedBranchId,
          campaignId: selectedCampaignId || null,
          spend: parseFloat(spend),
          quantity: parseInt(quantity) || 1,
          visit,
          notes: notes || null,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to record transaction')
        setLoading(false)
        return
      }

      setSuccess(true)
      setTimeout(() => {
        router.refresh()
        // Reset form
        setCustomerId('')
        setSpend('')
        setQuantity('1')
        setNotes('')
        setSuccess(false)
      }, 2000)
    } catch (err) {
      setError('An error occurred. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Record Transaction</CardTitle>
          <CardDescription>
            Scan customer QR code and enter transaction details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <QRScanner
            onScan={(id) => setCustomerId(id)}
            onManualEnter={(id) => setCustomerId(id)}
          />
        </CardContent>
      </Card>

      {customerId && (
        <Card>
          <CardHeader>
            <CardTitle>Transaction Details</CardTitle>
            <CardDescription>
              Customer ID: {customerId}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="rounded-md bg-destructive/15 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}
              {success && (
                <div className="rounded-md bg-green-500/15 p-3 text-sm text-green-700 dark:text-green-400">
                  Transaction recorded successfully!
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="branch">Branch *</Label>
                <select
                  id="branch"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                  required
                >
                  <option value="">Select a branch</option>
                  {branches.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="campaign">Campaign (Optional)</Label>
                <select
                  id="campaign"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={selectedCampaignId}
                  onChange={(e) => setSelectedCampaignId(e.target.value)}
                >
                  <option value="">No campaign</option>
                  {availableCampaigns.map((campaign) => (
                    <option key={campaign.id} value={campaign.id}>
                      {campaign.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="spend">Spend Amount ($) *</Label>
                <Input
                  id="spend"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={spend}
                  onChange={(e) => setSpend(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="visit"
                  checked={visit}
                  onChange={(e) => setVisit(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <Label htmlFor="visit" className="cursor-pointer">
                  Count as visit
                </Label>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Input
                  id="notes"
                  type="text"
                  placeholder="Additional notes..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Recording...' : 'Record Transaction'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
