'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'

interface Customer {
  customer: {
    id: string
    user: {
      id: string
      name: string
      email: string
    }
  }
  totalPoints: number
  lastVisit: Date | null
  campaigns: Array<{
    campaignId: string
    campaignName: string
    points: number
  }>
  eligibleRewards: number
  redeemedRewards: number
}

interface Campaign {
  id: string
  name: string
}

interface CustomerTableProps {
  customers: Customer[]
  campaigns: Campaign[]
}

export function CustomerTable({ customers, campaigns }: CustomerTableProps) {
  const [filterCampaign, setFilterCampaign] = useState('')
  const [filterLastVisit, setFilterLastVisit] = useState<number | null>(null)
  const [filterMinPoints, setFilterMinPoints] = useState('')

  const filteredCustomers = customers.filter((c) => {
    if (filterCampaign && !c.campaigns.some((camp) => camp.campaignId === filterCampaign)) {
      return false
    }
    if (filterLastVisit && c.lastVisit) {
      const daysSince = Math.floor(
        (Date.now() - new Date(c.lastVisit).getTime()) / (1000 * 60 * 60 * 24)
      )
      if (daysSince > filterLastVisit) {
        return false
      }
    }
    if (filterMinPoints && c.totalPoints < parseFloat(filterMinPoints)) {
      return false
    }
    return true
  })

  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-4 space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="text-sm font-medium mb-2 block">Filter by Campaign</label>
              <select
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={filterCampaign}
                onChange={(e) => setFilterCampaign(e.target.value)}
              >
                <option value="">All campaigns</option>
                {campaigns.map((campaign) => (
                  <option key={campaign.id} value={campaign.id}>
                    {campaign.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Last Visit (days)</label>
              <select
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={filterLastVisit || ''}
                onChange={(e) =>
                  setFilterLastVisit(e.target.value ? parseInt(e.target.value) : null)
                }
              >
                <option value="">Any time</option>
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Minimum Points</label>
              <input
                type="number"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={filterMinPoints}
                onChange={(e) => setFilterMinPoints(e.target.value)}
                placeholder="Any"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="grid grid-cols-6 gap-4 p-2 font-medium text-sm border-b">
            <div>Name</div>
            <div>Email</div>
            <div>Total Points</div>
            <div>Last Visit</div>
            <div>Eligible Rewards</div>
            <div>Redeemed</div>
          </div>
          {filteredCustomers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No customers found
            </div>
          ) : (
            filteredCustomers.map((customer) => (
              <div
                key={customer.customer.id}
                className="grid grid-cols-6 gap-4 p-2 border-b hover:bg-accent/50"
              >
                <div>{customer.customer.user.name}</div>
                <div className="text-sm text-muted-foreground">
                  {customer.customer.user.email}
                </div>
                <div>{customer.totalPoints.toFixed(0)}</div>
                <div className="text-sm text-muted-foreground">
                  {customer.lastVisit
                    ? `${Math.floor(
                        (Date.now() - new Date(customer.lastVisit).getTime()) /
                          (1000 * 60 * 60 * 24)
                      )} days ago`
                    : 'Never'}
                </div>
                <div>{customer.eligibleRewards}</div>
                <div>{customer.redeemedRewards}</div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
