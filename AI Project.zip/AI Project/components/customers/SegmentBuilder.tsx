'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface Campaign {
  id: string
  name: string
}

interface Segment {
  campaignId?: string
  lastVisitDays?: number
  minPoints?: number
  hasEligibleRewards?: boolean
}

interface SegmentBuilderProps {
  campaigns: Campaign[]
  segment: Segment
  onChange: (segment: Segment) => void
}

export function SegmentBuilder({
  campaigns,
  segment,
  onChange,
}: SegmentBuilderProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Target Segment</CardTitle>
        <CardDescription>
          Define which customers should receive this email
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Campaign (Optional)</Label>
          <select
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            value={segment.campaignId || ''}
            onChange={(e) =>
              onChange({
                ...segment,
                campaignId: e.target.value || undefined,
              })
            }
          >
            <option value="">All campaigns</option>
            {campaigns.map((campaign) => (
              <option key={campaign.id} value={campaign.id}>
                {campaign.name}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <Label>Last Visit Within (days, Optional)</Label>
          <Input
            type="number"
            min="1"
            value={segment.lastVisitDays || ''}
            onChange={(e) =>
              onChange({
                ...segment,
                lastVisitDays: e.target.value
                  ? parseInt(e.target.value)
                  : undefined,
              })
            }
            placeholder="e.g., 30"
          />
        </div>

        <div className="space-y-2">
          <Label>Minimum Points (Optional)</Label>
          <Input
            type="number"
            min="0"
            value={segment.minPoints || ''}
            onChange={(e) =>
              onChange({
                ...segment,
                minPoints: e.target.value
                  ? parseFloat(e.target.value)
                  : undefined,
              })
            }
            placeholder="e.g., 100"
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="hasEligibleRewards"
            checked={segment.hasEligibleRewards || false}
            onChange={(e) =>
              onChange({
                ...segment,
                hasEligibleRewards: e.target.checked || undefined,
              })
            }
            className="h-4 w-4"
          />
          <Label htmlFor="hasEligibleRewards" className="cursor-pointer">
            Has eligible but unredeemed rewards
          </Label>
        </div>
      </CardContent>
    </Card>
  )
}
