'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface QRScannerProps {
  onScan: (customerId: string) => void
  onManualEnter?: (customerId: string) => void
}

export function QRScanner({ onScan, onManualEnter }: QRScannerProps) {
  const [manualInput, setManualInput] = useState('')
  const [error, setError] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // In a real implementation, you would use a QR code scanning library
    // For now, we'll just read the file and try to extract text
    // This is a simplified version - you'd want to use html5-qrcode or similar
    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      // Assume the QR code contains the customer ID directly
      if (text && text.length > 0) {
        onScan(text.trim())
      } else {
        setError('Could not read QR code from image')
      }
    }
    reader.readAsText(file)
  }

  const handleManualSubmit = () => {
    if (!manualInput.trim()) {
      setError('Please enter a customer ID')
      return
    }
    setError('')
    if (onManualEnter) {
      onManualEnter(manualInput.trim())
    } else {
      onScan(manualInput.trim())
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Scan Customer QR Code</CardTitle>
        <CardDescription>
          Scan or upload QR code image, or enter customer ID manually
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <div className="rounded-md bg-destructive/15 p-3 text-sm text-destructive">
            {error}
          </div>
        )}
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Upload QR Code Image</label>
          <Input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileUpload}
          />
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">Or</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Enter Customer ID</label>
          <div className="flex gap-2">
            <Input
              placeholder="Customer ID"
              value={manualInput}
              onChange={(e) => {
                setManualInput(e.target.value)
                setError('')
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleManualSubmit()
                }
              }}
            />
            <Button onClick={handleManualSubmit}>Enter</Button>
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          Note: For production, implement camera-based QR scanning using html5-qrcode library
        </div>
      </CardContent>
    </Card>
  )
}
