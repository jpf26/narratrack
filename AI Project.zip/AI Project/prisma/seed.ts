import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Create merchant user
  const merchantUser = await prisma.user.create({
    data: {
      email: 'merchant@example.com',
      passwordHash: await bcrypt.hash('password123', 10),
      name: 'Test Merchant',
    },
  })

  const merchant = await prisma.merchant.create({
    data: {
      userId: merchantUser.id,
      businessName: 'Coffee Shop',
      slug: 'coffee-shop',
    },
  })

  // Create customer user
  const customerUser = await prisma.user.create({
    data: {
      email: 'customer@example.com',
      passwordHash: await bcrypt.hash('password123', 10),
      name: 'Test Customer',
    },
  })

  const customer = await prisma.customer.create({
    data: {
      userId: customerUser.id,
      phone: '+1234567890',
    },
  })

  // Create branches
  const branch1 = await prisma.branch.create({
    data: {
      merchantId: merchant.id,
      name: 'Downtown Branch',
      address: '123 Main St',
      phone: '+1234567891',
    },
  })

  const branch2 = await prisma.branch.create({
    data: {
      merchantId: merchant.id,
      name: 'Uptown Branch',
      address: '456 Oak Ave',
      phone: '+1234567892',
    },
  })

  // Create campaign
  const campaign = await prisma.campaign.create({
    data: {
      merchantId: merchant.id,
      name: 'Summer Rewards',
      description: 'Earn points and get free drinks!',
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-12-31'),
      promos: {
        create: [
          {
            promoType: 'SPEND_MULTIPLIER',
            multiplier: 1.5,
            minSpend: 10,
          },
          {
            promoType: 'FLAT_BONUS',
            multiplier: 5,
          },
        ],
      },
      milestones: {
        create: [
          {
            rewardName: 'Free Coffee',
            pointsNeeded: 50,
            rewardDescription: 'Get a free coffee',
            order: 1,
          },
          {
            rewardName: 'Free Pastry',
            pointsNeeded: 100,
            rewardDescription: 'Get a free pastry',
            order: 2,
          },
          {
            rewardName: '50% Off',
            pointsNeeded: 200,
            rewardDescription: 'Get 50% off your next purchase',
            order: 3,
          },
        ],
      },
    },
  })

  // Clone campaign to branches
  await prisma.branchCampaign.createMany({
    data: [
      {
        branchId: branch1.id,
        campaignId: campaign.id,
      },
      {
        branchId: branch2.id,
        campaignId: campaign.id,
      },
    ],
  })

  console.log('Seed completed!')
  console.log('Merchant login: merchant@example.com / password123')
  console.log('Customer login: customer@example.com / password123')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
