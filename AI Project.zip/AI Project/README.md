# Loyalty Tracker Web App

A full-stack loyalty tracker application built with Next.js, TypeScript, PostgreSQL, and Prisma.

## Features

- **Points-based loyalty system**: Customers earn points through transactions
- **Multi-branch support**: Merchants can manage multiple branches
- **Campaign management**: Create campaigns with promos and milestones
- **QR code scanning**: Staff can scan customer QR codes to record transactions
- **Customer analytics**: Merchants can view customer progress and send email campaigns
- **Progress tracking**: Track customer progress per branch and campaign

## Tech Stack

- **Frontend**: Next.js 14+ (App Router), TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL with Prisma ORM
- **Auth**: NextAuth.js
- **Email**: Resend

## Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- npm or yarn
- Resend API key (for email functionality - optional for development)

### Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

Edit `.env` and add:
- `DATABASE_URL`: Your PostgreSQL connection string
- `NEXTAUTH_SECRET`: A random secret string (generate with `openssl rand -base64 32`)
- `NEXTAUTH_URL`: Your app URL (http://localhost:3000 for development)
- `RESEND_API_KEY`: Your Resend API key (optional, emails will be skipped if not set)

4. Set up the database:
```bash
npm run db:generate
npm run db:push
npm run db:seed
```

5. Run the development server:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Default Credentials

After seeding:
- **Merchant**: merchant@example.com / password123
- **Customer**: customer@example.com / password123

### PWA Icons

To enable PWA functionality, add icon files:
- `public/icon-192.png` (192x192 pixels)
- `public/icon-512.png` (512x512 pixels)

## Project Structure

```
app/
  (auth)/          # Authentication pages
  (dashboard)/     # Dashboard pages for customers and merchants
  api/             # API routes
lib/               # Utility functions and configurations
prisma/            # Prisma schema and migrations
components/        # React components
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run db:generate` - Generate Prisma client
- `npm run db:push` - Push schema to database
- `npm run db:migrate` - Run migrations
- `npm run db:seed` - Seed database
- `npm run db:studio` - Open Prisma Studio

## License

MIT
