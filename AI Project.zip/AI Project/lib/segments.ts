import { prisma } from './db'

interface Segment {
  campaignId?: string
  lastVisitDays?: number
  minPoints?: number
  hasEligibleRewards?: boolean
}

export async function resolveRecipients(segment: Segment, merchantId: string) {
  const where: any = {
    branch: { merchantId },
  }

  if (segment.campaignId) {
    where.campaignId = segment.campaignId
  }

  if (segment.lastVisitDays) {
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() - segment.lastVisitDays)
    where.lastTransactionAt = { gte: cutoff }
  }

  if (segment.minPoints !== undefined) {
    where.pointsAccumulated = { gte: segment.minPoints }
  }

  if (segment.hasEligibleRewards) {
    // This is a simplified check - in production you'd want more sophisticated JSON querying
    where.rewardsEligible = { not: { equals: [] } }
  }

  const progressRecords = await prisma.customerCampaignProgress.findMany({
    where,
    include: {
      customer: {
        include: {
          user: true,
        },
      },
    },
    distinct: ['customerId'],
  })

  return progressRecords.map((p) => ({
    customerId: p.customerId,
    email: p.customer.user.email,
    name: p.customer.user.name,
  }))
}
