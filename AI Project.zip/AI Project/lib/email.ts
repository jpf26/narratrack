import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function sendEmail({
  to,
  subject,
  html,
}: {
  to: string
  subject: string
  html: string
}) {
  if (!process.env.RESEND_API_KEY) {
    console.warn('RESEND_API_KEY not set, skipping email send')
    return { id: 'mock-id', error: null }
  }

  try {
    const { data, error } = await resend.emails.send({
      from: 'Loyalty Tracker <onboarding@resend.dev>',
      to,
      subject,
      html,
    })

    if (error) {
      throw error
    }

    return { id: data?.id, error: null }
  } catch (error) {
    console.error('Email send error:', error)
    throw error
  }
}
