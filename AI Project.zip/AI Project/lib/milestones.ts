import { Decimal } from '@prisma/client/runtime/library'

interface Milestone {
  id: string
  pointsNeeded: number
}

interface Progress {
  pointsAccumulated: Decimal
  rewardsEligible: string[]
  rewardsRedeemed: string[]
}

export function updateRewardsEligible(
  progress: Progress,
  milestones: Milestone[]
): string[] {
  const eligible = [...(progress.rewardsEligible || [])]
  const redeemed = [...(progress.rewardsRedeemed || [])]
  const points = progress.pointsAccumulated.toNumber()

  const sortedMilestones = milestones.sort((a, b) => a.pointsNeeded - b.pointsNeeded)

  for (const milestone of sortedMilestones) {
    if (
      points >= milestone.pointsNeeded &&
      !eligible.includes(milestone.id) &&
      !redeemed.includes(milestone.id)
    ) {
      eligible.push(milestone.id)
    }
  }

  return eligible
}
