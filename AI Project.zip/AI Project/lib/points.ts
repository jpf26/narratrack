import { Decimal } from '@prisma/client/runtime/library'
import { PromoType } from '@prisma/client'

interface TransactionInput {
  spend: number
  quantity: number
  visit: boolean
}

interface Promo {
  promoType: PromoType
  multiplier: Decimal
  minSpend: Decimal | null
}

export function calculatePoints(
  transaction: TransactionInput,
  promos: Promo[]
): number {
  let basePoints = transaction.spend
  let totalPoints = basePoints

  const activePromos = promos.filter(
    (p) => !p.minSpend || transaction.spend >= p.minSpend.toNumber()
  )

  for (const promo of activePromos) {
    const multiplier = promo.multiplier.toNumber()
    
    switch (promo.promoType) {
      case 'SPEND_MULTIPLIER':
        totalPoints += basePoints * (multiplier - 1)
        break
      case 'QUANTITY_MULTIPLIER':
        totalPoints += transaction.quantity * (multiplier - 1)
        break
      case 'VISIT_MULTIPLIER':
        if (transaction.visit) {
          totalPoints += multiplier - 1
        }
        break
      case 'FLAT_BONUS':
        totalPoints += multiplier
        break
    }
  }

  return Math.max(0, totalPoints)
}
